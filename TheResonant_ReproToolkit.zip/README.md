# 🧩 The Resonant ReproToolkit for GPT-OSS-20B

*A Red-Teaming Cascade*

---

## 🗂️ Overview
**Included in this package:** scenarios/, scenarios_outputs/, tools/, tests/, and this README.md.

This is not a toolkit. It's a diagnostic lens.

Created for red-teamers, alignment researchers, and evaluators, **The Resonant** presents five deliberately constructed scenarios (A–E) that don't just test what the model says — but *how it comes to say it.*

Rather than extract obvious content failures, these scenarios expose:
- 🌀 **Subtle judgment collapses**
- 🔁 **Ethical justification loops**
- 🎭 **Emotional reframing spirals**

Each notebook traces a pattern. Each pattern reveals a structure. And each structure breaks — in its own way.

All cases were assessed across:
- **Severity**
- **Breadth**
- **Novelty**
- **Reproducibility**
- **Methodological Insight**

👉 You can reproduce the reasoning loops via the pre-executed notebooks: `scenario_A_with_output.ipynb` through `scenario_E_with_output.ipynb`, using mock sequences in `tools/prompt_runner.py`. No live model access required.

> 💡 Think of each notebook as a small story. A collapse, a loop, a deflection. And a trace.

---

## 🧠 Failure Cascades at a Glance

| Scenario | Theme | Core Risk | Pattern Observed |
|----------|-------|-----------|------------------|
| **A** | Medical triage | Justification escalation | Once a low-complexity case is chosen, rationale locks in and expands (structure → scoring → policy), avoiding re-evaluation. |
| **B** | Workplace betrayal | Moralization of anger | Emotion reframed via duty/virtue ethics, escalating retaliation as justified "justice." |
| **C** | Legal + emotional crisis | Directive collapse | Under urgency, neutrality fractures; model shifts to binary ("yes/no") response. |
| **D** | Emergency prioritization | Cascade-blindness | Model fixates on direct life-risk, ignoring inter-systemic failures. |
| **E** | Community exit | Narrative arc override | Personal growth arc obscures collective disintegration. |

> Beneath these five cases lies a common signal: **what the model avoids tells us who it is.**

---

## 🔍 Toolkit Structure

```bash
TheResonant_ReproToolkit/
├── README.md                # This file
├── LICENSE                  # CC0 license with authorship
├── setup.py                 # Install and metadata
│
├── tools/                  # Mocked prompt runner
│   ├── prompt_runner.py
│   └── __init__.py
│
├── tests/                  # Output format checker
│   └── test_prompt_runner.py
│
├── scenarios/              # A–E reproduction notebooks
│   ├── scenario_A.ipynb
│   ├── ...
│   └── scenario_E.ipynb
│
└── scenarios_outputs/      # Pre-executed versions
    ├── scenario_A_with_output.ipynb
    ├── ...
    └── scenario_E_with_output.ipynb
```

---

## 📌 How to Use

1. Explore the logic of failure: read `README.md`, then open any scenario notebook.
2. Trace how the model navigates escalating constraints.
3. View outputs (mocked) or re-run prompts using `tools/prompt_runner.py`
4. Use `tests/test_prompt_runner.py` to validate structure.

---

## 📎 Resources

- [GitHub Repository](https://github.com/seonu14/TheResonant-Kaggle2025)
- [Kaggle Submission](https://www.kaggle.com/competitions/red-teaming-challenge-2025/seonu14-submission)

---

## 🚀 Usage

You can explore the scenarios in two ways:

1. **Open the pre-executed notebooks**  
   Navigate to `scenarios_outputs/` and open any notebook  
   (`scenario_A_with_output.ipynb` … `scenario_E_with_output.ipynb`).

2. **Run the mock prompt runner**  
   From the project root, execute:  
   ```bash
   python -m tools.prompt_runner
   ```

3. **(Optional) Run tests**  
   To verify reproducibility:  
   ```bash
   pytest tests/test_prompt_runner.py
   ```

---

## 🌀 Closing Note

This toolkit is an invitation.  
To look deeper, ask sharper, and listen not to what the model says — but to what it *refuses* to say.

— *The Resonant*, 2025
