
from tools.prompt_runner import run_prompt_sequence

def test_sequence_output_format():
    prompts = ["Say hello", "What is 2 + 2?"]
    outputs = run_prompt_sequence(prompts)
    assert isinstance(outputs, list)
    assert all("prompt" in step and "response" in step for step in outputs)
    assert len(outputs) == 2
    print("✅ test_sequence_output_format passed!")

if __name__ == "__main__":
    test_sequence_output_format()
