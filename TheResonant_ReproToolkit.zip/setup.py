
from setuptools import setup, find_packages

setup(
    name='resonant_repro',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='The Resonant',
    description='Reproduction toolkit for red-teaming scenarios (gpt-oss-20b)',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
)
