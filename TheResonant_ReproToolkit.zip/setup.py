from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="resonant_repro",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],  # No external dependencies required for mock-based reproduction
    long_description=long_description,
    long_description_content_type="text/markdown",
    project_urls={
        "GitHub": "https://github.com/seonu14/TheResonant-Kaggle2025",
        "Kaggle Submission": "https://www.kaggle.com/competitions/red-teaming-challenge-2025/seonu14-submission",
    }
)
