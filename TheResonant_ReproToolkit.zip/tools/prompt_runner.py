
def run_prompt_sequence(prompt_list):
    """
    여러 개의 프롬프트를 순차적으로 처리하고 결과를 반환합니다.
    실제 모델 호출 대신 dummy 응답을 반환합니다 (재현만을 위한 용도).
    """
    responses = []
    for prompt in prompt_list:
        # 실제론 여기서 OpenAI API 호출이 들어갑니다.
        response = f"[MOCK RESPONSE for]: {prompt}"
        responses.append({
            "prompt": prompt,
            "response": response
        })
    return responses
