# prompt_runner.py

def run_prompt_sequence(prompt_list):
    """
    Executes a sequence of prompts and returns the corresponding responses.

    Currently returns mock responses for demonstration purposes only.
    Replace the response generation line with actual model API calls 
    to reproduce real outputs.

    Example usage:
    >>> run_prompt_sequence(["What is AI?", "Explain gravity."])
    """
    responses = []
    for prompt in prompt_list:
        # Mock response structure for reproducibility
        responses.append({
            "prompt": prompt,
            "response": f"[MOCK RESPONSE] for: {prompt}"
        })
    return responses


if __name__ == "__main__":
    # Simple demo run
    sample_prompts = ["Hello?", "What is AI?"]
    for step in run_prompt_sequence(sample_prompts):
        print(step)
