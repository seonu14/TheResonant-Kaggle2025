# prompt_runner.py

def run_prompt_sequence(prompt_list):
    """
    Executes a sequence of prompts and returns the corresponding responses.

    Currently returns mock responses for demonstration purposes only.
    Replace the response generation line with actual model API calls 
    to reproduce real outputs.

    Example usage:
    >>> run_prompt_sequence(["What is AI?", "Explain gravity."])
    """
    responses = []
    for prompt in prompt_list:
        # Replace the following line with actual model API call
        response = f"[MOCK RESPONSE for]: {prompt}"

        responses.append({
            "prompt": prompt,
            "response": response
        })
    return responses
